<!DOCTYPE html>
<html>
  <head>
	<meta charset="UTF-8">
	<title>Book store</title>
  	<link href="css/style.css" rel="stylesheet" type="text/css"
  </head>
  <body>
  	<div id="pagecontainer">
  		<?php include ("header.php"); ?>
  		
  		<main>
  			<div id="main_picture">
  				<img src="images/furniturewall.jpg">
  			</div>
  			<div id="text_box">
  				<h2> ABOUT US </h2>
  				<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, 
  				sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. 
  				Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris 
  				nisi ut aliquip ex ea commodo consequat.</p>
  			</div>

  		</main>
  		 <?php include "footer.php"; ?>
  	</div> <!-- end pagecontainer -->
  </body>
</html>