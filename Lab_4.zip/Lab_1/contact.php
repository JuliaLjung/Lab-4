<!DOCTYPE html>
<html>
  <head>
	<meta charset="UTF-8">
	<title>Book store</title>
  	<link href="css/style.css" rel="stylesheet" type="text/css"
  </head>
  <body>
  	<div id="pagecontainer">
  		
  			<?php include ("header.php"); ?>
  		
  		
  		<main>
  			<div id="contact-form">
          <form>
          <h2>Contact us</h2>
          Name:<br>
          <input type="text"><br>
          E-mail:<br>
          <input type="text"><br>
          Your message:<br>
          <input type="text"><br>
          <input type="submit" value="Submit">
          </form>
        </div>

  		</main>
  		<footer>
  			<?php include 'footer.php'; ?> 
  		</footer>
  	</div> <!-- end pagecontainer -->
  </body>
</html>