<!DOCTYPE html>
      <footer>
  			<div id="footer_box">
  				<ul class="box">
  					<li>
  						<div class="inner">
  							<h3>Book Store</h3>
  							<p>Bokgatan 33<br>55 456 Stockholm</p>
  						</div>
  					</li>
  					<li>
  						<div class="inner">
                <h3>Contact</h3>
  							<p>Tel: 0846283939<br> Mail: bookstore@mail.se</p>
  						</div>
  					</li>
  				</ul>
  			</div> 
  		</footer>