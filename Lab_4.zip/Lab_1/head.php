<!DOCTYPE html>
<html>
  <head>
	<meta charset="UTF-8">
	<title>Book store</title>
  	<link href="css/style.css" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="css/blueimp-gallery.min.css">
  </head>