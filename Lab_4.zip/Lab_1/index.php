<!DOCTYPE html>
<html>
    <?php include 'head.php'; ?>

  <body>
  	<div id="pagecontainer">
 

      <?php include 'header.php'; ?>
  		
  		<main>
  			<div id="main_picture">
  				<img src="images/chanelbooks.jpg">
  			</div>
  			<div id="text_box">
  				<h2> Welcome to the book Store! </h2>
  				<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, 
  				sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. 
  				Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris 
  				nisi ut aliquip ex ea commodo consequat.<br><br>sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. 
          Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris 
          nisi ut aliquip ex ea commodo.<br><br>Lorem ipsum dolor sit amet, consectetur adipisicing elit, 
          sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. 
          Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris 
          nisi ut aliquip ex ea commodo consequat</p>
  			</div>

  		</main>

        <?php include 'footer.php'; ?>

  	</div> <!-- end pagecontainer -->
  </body>
</html>