<!DOCTYPE html>

<html>
 <?php include 'head.php'; ?>
  <body>
  	<div id="pagecontainer">
  		<?php include ("header.php"); ?>
  		<main>
  			<h2>LOG IN</h2>
  			<?php include ("SQLinjection.php"); ?>

  		
  		</main>
		
		<footer>
  		 <?php include "footer.php"; ?>
  		</footer>

  	</div> <!-- end pagecontainer -->

  </body>
</html>